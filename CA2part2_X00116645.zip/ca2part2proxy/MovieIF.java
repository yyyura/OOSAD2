public interface MovieIF {

    void play();

}

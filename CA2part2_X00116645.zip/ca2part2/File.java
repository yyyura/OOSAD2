public class File {// Caretaker opekun

    Save save;//ssilka na save

    public Save getSave() {
        return save;
    }

    public void setSave(Save save) {
        this.save = save;
    }

}

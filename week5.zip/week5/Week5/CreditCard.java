package Week5;

public class CreditCard {

	private String nameoncard;
	private String numberoncard;

	public String getNameoncard() {
		return this.nameoncard;
	}

	public void setNameoncard(String nameoncard) {
		this.nameoncard = nameoncard;
	}

	public String getNumberoncard() {
		return this.numberoncard;
	}

	public void setNumberoncard(String numberoncard) {
		this.numberoncard = numberoncard;
	}

	public CreditCard() {
		// TODO - implement CreditCard.CreditCard
		throw new UnsupportedOperationException();
	}

	public void checkOut() {
		// TODO - implement CreditCard.checkOut
		throw new UnsupportedOperationException();
	}

}
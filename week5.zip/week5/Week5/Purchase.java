package Week5;

public class Purchase {

	private int id;
	private int VAT;
	private double total;

	public int getVAT() {
		return this.VAT;
	}

	public void setVAT(int VAT) {
		this.VAT = VAT;
	}

	public double getTotal() {
		return this.total;
	}

	public Purchase() {
		// TODO - implement Purchase.Purchase
		throw new UnsupportedOperationException();
	}

	public void computeCurrentTotal() {
		// TODO - implement Purchase.computeCurrentTotal
		throw new UnsupportedOperationException();
	}

}